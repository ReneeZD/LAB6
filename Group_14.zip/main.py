import ure,socket,gc,time

def do_connect():
    import network
    sta_if = network.WLAN(network.STA_IF)
    if not sta_if.isconnected():
        print('connecting to network...')
        sta_if.active(True)
        # sta_if.connect('TC8715D60', 'TC8715DB26D60')
        sta_if.connect('Columbia University', '')
        while not sta_if.isconnected():
            pass
    print('network config:', sta_if.ifconfig())
do_connect()
def sendtweet(command):
    url='https://api.thingspeak.com/apps/thingtweet/1/statuses/update'
    _, _, host, path = url.split('/', 3)
    addr = socket.getaddrinfo(host, 80)[0][-1]
    s = socket.socket()
    s.connect(addr)
    j_data = "api_key=11EHXZ9DFM2PDUKY&status="+command
    length = len(j_data)
    s.send(b'POST /%s HTTP/1.1\r\nHost: %s\r\nConnection: close\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: %s\r\n\r\n%s' % (path, host, length, j_data))
    s.close()
    gc.collect()

def getweather():
    host = '54.149.75.206'
    path = 'weather'
    addr = socket.getaddrinfo(host, 80)[0][-1]
    s = socket.socket()
    s.connect(addr)
    s.send(bytes('GET /%s HTTP/1.0\r\nHost: %s\r\n\r\n' % (path, host), 'utf8'))
    data = s.recv(400)
    # print(data)
    temp = ure.search("temp\': (.*), u", data)
    weather = ure.search("tion\': u\'(.*)\'}]{u", data)
    return temp.group(1),weather.group(1)

def display(command):
    global b,c,i,j,d
    x.contrast(int(adc.read()/4))
    if command=="time":
        x.fill(0)
        a = rtc.datetime()
        if b == 1:
            b = 0
            rtc.datetime((a[0], a[1], a[2], a[3], a[4] + 1, a[5], a[6], a[7]))
        if c == 1:
            c = 0
            rtc.datetime((a[0], a[1], a[2], a[3], a[4], a[5] + 1, a[6], a[7]))

        if a[4]==i and a[5]==j:

            pwm1.freq(500)
            pwm1.duty(512)
            x.text('o(^_^)o',64,1)
        else:
            pwm1.freq(500)
            pwm1.duty(0)
        x.text(str(a[4]) + ':' + str(a[5]) + ':' + str(a[6]), 1, 1)
        x.text('alarm:' + str(i) + ':' + str(j) + ':' + '0', 1, 16)
        x.show()
    else:
        pwm1.freq(500)
        pwm1.duty(0)
        if command=="off":
            x.fill(0)
            x.show()
        elif command=="display":
            x.fill(1)
            x.show()
        elif command=="weather":
            global temp, weather
            temp, weather = getweather()
            x.fill(0)
            x.text(str(temp), 1, 1)
            x.text(str(weather), 1, 16)
            x.show()
        elif command == "last weather":
            global temp, weather
            x.fill(0)
            x.text(str(temp), 1, 1)
            x.text(str(weather), 1, 16)
            x.show()
        else:
            x.fill(0)
            x.text(command,1,1)
            x.show()




def callback(p12):
    global b
    global i
    global d
    time.sleep(0.1)     #debouncing

    if (p12.value()==0):
        if d==0:
            b=1
        else:
            i=i+1



def callback1(p13):
    global c
    global j
    global d
    time.sleep(0.1)  # debouncing

    if (p13.value() == 0):
        if d==0:
            c = 1
        else:
            j=j+1





def post(x,y,z):
    host = 'ec2-54-149-75-206.us-west-2.compute.amazonaws.com'
    path = 'post'
    addr = socket.getaddrinfo(host, 80)[0][-1]
    s1 = socket.socket()
    s1.connect(addr)
    j_data='{"x":'+str(x)+', "y":'+str(y)+', "z":'+str(z)+'}'
    length = len(j_data)
    s1.send(b'POST /%s HTTP/1.1\r\nHost: %s\r\nContent-Type: application/json\r\nContent-Length: %s\r\nCache-Control: no-cache\r\n\r\n%s' % (path,host,length,j_data))
    s1.close()

def accelerometer():
    import ustruct
    from machine import SPI
    pcs = Pin(15, Pin.OUT)
    hspi = SPI(-1, baudrate=100000, polarity=1, phase=1, sck=Pin(14), mosi=Pin(12), miso=Pin(16))
    pcs.low()
    pcs.high()
    pcs.low()
    hspi.write(b'\x2D')
    hspi.write(b'\x08')
    pcs.high()
    pcs.low()
    hspi.write(b'\xb2')
    # print ("X")
    x1 = int(ustruct.unpack('b', hspi.read(1))[0])
    pcs.high()

    pcs.low()
    hspi.write(b'\xb4')
    # print ("Y")
    y1 = int(ustruct.unpack('b', hspi.read(1))[0])
    pcs.high()

    pcs.low()
    hspi.write(b'\xb6')
    # print ("Z")
    z1 = int(ustruct.unpack('b', hspi.read(1))[0])
    pcs.high()
    #post(20, 20, 20)
    print(x1,y1,z1)
    post(x1, y1, z1)

b = 0
c = 0
d = 0
# alarm time: hour and min
i = 3
j = 3
tweetflag=0
from machine import ADC,Pin, I2C, RTC
adc = ADC(0)


rtc = RTC()
rtc.datetime((2016,12,30,4,1,1,1,1))
i2c = I2C(scl=Pin(5), sda=Pin(4), freq=100000)
addr = socket.getaddrinfo('0.0.0.0', 80)[0][-1]
s0 = socket.socket()
s0.bind(addr)
s0.listen(1)
s0.settimeout(1)
command="off"
print('listening on', addr)
l='nothing'
import ssd1306
x=ssd1306.SSD1306_I2C(128,32,i2c)
gc.collect()

from machine import PWM
pwm1 = PWM(Pin(0))
p12 = Pin(2, Pin.IN, Pin.PULL_UP)
p13 = Pin(13, Pin.IN, Pin.PULL_UP)
p12.irq(trigger=Pin.IRQ_FALLING, handler=callback)
p13.irq(trigger=Pin.IRQ_FALLING, handler=callback1)

while True:

    try:
        cl,_ = s0.accept()
        cl.setblocking(False)
        print('client connected from', addr)
        while True:
            line = cl.read()
            if line!=None:
                break
        temp1 = ure.search('"key":"(.*)"}', line)
        command=temp1.group(1)
        cl.send(b'HTTP/1.0 200 OK\r\nServer: esp8266\r\nContent-Type: application/json\r\nContent-Length: 0\r\nConnection: Closed\r\n\r\n ')
        cl.close()

    except:
        if command == "tweet":
            tweetflag=1
        elif tweetflag==1:
            tweetflag=0
            l=command
            sendtweet(command)
        if command=='last':
            command=l
        if command=='change time':
            d=0
            command="time"
        if command=='change alarm':
            d=1
            command="time"
        display(command)


        accelerometer()
    finally:
        gc.collect()
        # print(d)