package com.example.ray.myapplication;


import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;


public class MainActivity extends Activity {

    private TextView txtSpeechInput;
    private TextView responseText;
    private ImageButton btnSpeak;
    private final int REQ_CODE_SPEECH_INPUT = 100;
    private final static String output = "Hello world";
    private String instruction;
    private static final String TAG = MainActivity.class.getSimpleName();
    static int response;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtSpeechInput = (TextView) findViewById(R.id.txtSpeechInput);
        btnSpeak = (ImageButton) findViewById(R.id.btnSpeak);
        responseText=(TextView)findViewById(R.id.responseText);


        // hide the action bar
        // getActionBar().hide();

        btnSpeak.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                promptSpeechInput();

            }
        });

    }

    /**
     * Showing google speech input dialog
     * */
    private void promptSpeechInput() {
        Log.d(TAG,"Inside promptSpeechInput");
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
                getString(R.string.speech_prompt));

        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getApplicationContext(),
                    getString(R.string.speech_not_supported),
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Receiving speech input
     * */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG,"In onActivityResult");


        switch (requestCode) {
            case REQ_CODE_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && null != data) {

                    ArrayList<String> result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

                    txtSpeechInput.setText(result.get(0));
                    instruction = result.get(0);
                    System.out.println(instruction);
                    new TryPost().execute();
                    if(response==200)
                    {
                        System.out.println("Here");
                        responseText.setText("response:   "+result.get(0));
                        response=0;
                    }
                    else
                    {
                        responseText.setText("Did not get response!");
                    }

                }

                break;
            }

        }
    }
    class TryPost extends AsyncTask<Void,Void,Void>
    {


        protected void onPreExecute() {
            //display progress dialog.

        }
        protected Void doInBackground(Void... params){
            String DEBUG_TAG = "debug";
            try{
                System.out.println("hello");
                // String myurl = "https://www.googleapis.com/geolocation/v1/geolocate?key=AIzaSyBFxPlZIJFN7nhnOIs5SkuFXHt1HctvNEY"; 
                URL url = new URL("http://cf9da822.ngrok.io");
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                //Log.d(DEBUG_TAG,"hi!!!!!!!");
                //            con.setReadTimeout(15001); 
                //            con.setConnectTimeout(15001);     c
                con.setDoInput(true);
                con.setDoOutput(true);
                JSONObject temp = new JSONObject();
                String t;
                temp.put("key", instruction);
                Log.d(TAG,instruction);
                t = temp.toString();
                con.setRequestProperty("Content-Type", "application/json");
                con.setRequestProperty("Accept", "application/json");
                con.setRequestProperty("Content-Length", ""+ t.length() );
                con.setRequestMethod("POST");
                OutputStreamWriter w = new OutputStreamWriter(con.getOutputStream());
                w.write(temp.toString());
                w.flush();
                w.close();
                System.out.println("after connecting");
                response = con.getResponseCode();
                System.out.println("response: "+response);
                Log.d(DEBUG_TAG, "THe response is: " + response);
                String answer = "";
                if(response == 200) {
                    String line;
                    BufferedReader reader = new BufferedReader((new InputStreamReader(con.getInputStream())));
                    while ((line = reader.readLine()) != null) {
                        answer += line;
                    }
                }else{
                    answer="";
                }
                Log.d(DEBUG_TAG,answer);
                return null;
            }catch(Exception e)
            {
                e.printStackTrace();
            }
            return null;
        }




        protected void onPostExecute(Void result) {
            // dismiss progress dialog and update ui
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

}